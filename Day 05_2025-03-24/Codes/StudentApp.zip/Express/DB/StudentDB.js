//array of student JSON details

let students = [
    {regno:'2021ict01',name:'Nethya',gender:'F'},
    {regno:'2021ict02',name:'Ramesha',gender:'F'},
    {regno:'2021ict03',name:'Elsa',gender:'F'},
    {regno:'2021ict04',name:'Kethaka',gender:'M'}
    ];

module.exports=students;