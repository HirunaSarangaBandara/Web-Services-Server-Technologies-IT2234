let student = [
    {RegNO : '2021ICT01', Name : "Georje", Gender : 'Male', Age : 25 , Coures : 'IT'},
    {RegNO : '2021ICT02', Name : "Alice", Gender : 'Female', Age : 23, Coures : 'IT'},
    {RegNO : '2021ICT03', Name : "Bob", Gender : 'Male', Age : 22, Coures : 'IT'},
    {RegNO : '2021ICT04', Name : "Nataliya", Gender : 'Female', Age : 22, Coures : 'IT'}
];

module.exports = student;